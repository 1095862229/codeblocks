#include <stdio.h>
#include <ctime>
#include "sort.h"


int main()
{
    int i,n=10;
    srand((unsigned)time(NULL));
    RecType R[MaxSize],R1[MaxSize],R2[MaxSize];
    RecType R3[MaxSize],R4[MaxSize],R5[MaxSize];
    for (i=0; i<n; i++)
    {
        R[i].key=rand();
        R1[i].key=R[i].key;
        R2[i].key=R[i].key;
        R3[i].key=R[i].key;
        R4[i].key=R[i].key;
        R5[i+1].key=R[i].key;
    }
    for (i=0; i<n; i++)
        printf("%d %d %d %d %d %d\n",R[i].key,R1[i].key,R2[i].key,R3[i].key,R4[i].key,R5[i].key);
//ֱ�Ӳ���
    InsertSort(R,n);
    printf("ֱ�Ӳ�������:");
    for (i=0; i<n; i++)
        printf("%d ",R[i].key);
//�۰����
    InsertSort1(R1,n);
    printf("\n");
    printf("�۰�����:");
    for (i=0; i<n; i++)
        printf("%d ",R1[i].key);
    printf("\n");
//ϣ������
    ShellSort(R2,n);
    printf("ϣ������:");
    for (i=0; i<n; i++)
        printf("%d ",R2[i].key);
    printf("\n");
//ð������
    BubbleSort(R3,n);
    printf("ð������:");
    for (i=0; i<n; i++)
        printf("%d ",R3[i].key);
    printf("\n");
//��������
    QuickSort(R4,0,n-1);
    printf("��������:");
    for (i=0; i<n; i++)
        printf("%d ",R4[i].key);
    printf("\n");
//������
    HeapSort(R5,n);
    printf("�������:");
    for (i=1; i<=n; i++)
        printf("%d ",R5[i].key);
    printf("\n");





    for (i=0; i<n; i++)
        printf("%d %d %d %d %d %d\n",R[i].key,R1[i].key,R2[i].key,R3[i].key,R4[i].key,R5[i+1].key);

    printf("\n");
    printf("\n");
    return 0;
}



/*˳���
    SqList *sq;
    ElemType x[6]={5,8,7,2,4,9};
    CreateList(sq,x,6);
    DispList(sq);
    return 0;
    */
/**<����
    LinkList *L;
    InitLinkList(L);
    LinkListInsert(L,1,15);
    LinkListInsert(L,1,10);
    LinkListInsert(L,1,5);
    LinkListInsert(L,1,20);
    DispLinkList(L);
    DestroyLinkList(L);
    return 0;

 */
/*  ���������
    srand((unsigned)time(NULL));
    for(int i=10;i>0;i--)
    {
        printf("%d\n",rand());
    }*/
